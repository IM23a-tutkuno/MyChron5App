INSTALLATION
------------

1. Copy the MyChron5App folder into assettocorsa\apps\python
2. Copy EuroStyle Normal.ttf into: assettocorsa\content\fonts
3. Activate the app in ContentManager (Settings/Assetto Corsa/Python Apps)
4. Enjoy!

-----------------------------------------------------------------------------------------------
!WATER/EXHAUST TEMP AND LAMBDA ARE FIXED VALUES AND DONT REPRESENT THE CARS/KARTS ACTUAL STATE!
-----------------------------------------------------------------------------------------------
Made by NoMichaelNo
Discord: nomichaelno61